<style>
	footer li a:focus{
		color:#fff;
	}
</style>
		<footer>
			<div class="container margin_120_95">
				<div class="row">
					<div class="col-lg-5 col-md-12 p-r-5">
						<p style="margin-bottom:0px;"><img src="img/external_images/main_school_logo-removebg-preview.png"
								style="margin-left:-30px;" width="150" height="100" data-retina="true" alt=""></p>
						<p>An education system refers to the economic and social factors that typically make up public schools at the federal, state or community levels. Such factors include public funding, school facilities, staffing, employee benefits, teaching resources and more. Education systems refer to the coordination of individuals infrastructure and functioning institutions and processes.</p>
						<div class="follow_us">
							<ul>
								<li>Follow us</li>
								<li><a href="#0"><i class="ti-facebook"></i></a></li>
								<li><a href="#0"><i class="ti-instagram"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 ml-lg-auto">
						<h5>Useful links</h5>
						<ul class="links" style="padding-top:20px;">
							<li><a href="index.php">Home</a></li>
							<li><a href="about.php">About</a></li>
							<li><a href="media-gallery.php">Gallery</a></li>
							<li><a href="contacts.php">Contacts</a></li>
							<li><a href="admission.php">Admission</a></li>
						</ul>
					</div>
					<div class="col-lg-3 col-md-6">
						<h5>Contact with Us</h5>
						<ul class="contacts" style="padding-top:20px;">
							<li><a href="tel://61280932400"><i class="ti-mobile"></i> +92 00 000 0000</a></li>
							<li><a href="mailto:info@udema.com"><i class="ti-email"></i> info@KGS.com</a></li>
						</ul>
						
					</div>
				</div>
				<!--/row-->
				<hr>
							
								<div id="copy" style="text-align: center;">Made with <i class="ti-heart"></i>  by Badar Tech</div>
			</div>
		</footer>
		<!--/footer-->
	</div>
	<!-- page -->

	<!-- COMMON SCRIPTS -->
	<script src="js/jquery-2.2.4.min.js"></script>
	<script src="js/common_scripts.js"></script>
	<script src="js/main.js"></script>
	<script src="assets/validate.js"></script>



    <!-- <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js"></script>
	<script type="text/javascript" src="js/mapmarker.jquery.js"></script>
	<script type="text/javascript" src="js/mapmarker_func.jquery.js"></script> -->
</body>

</html>